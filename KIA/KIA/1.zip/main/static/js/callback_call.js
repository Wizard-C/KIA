$('.js_button_click_active_test').click(function(){
	$('.js_form_test').fadeIn();
	$('.js_overlay').fadeIn();
})

$('.js_button_click_close').click(function(){
	$('.js_form_test').fadeOut();
	$('.js_overlay').fadeOut();
})

$('.js_button_click_active_more').click(function(){
	$('.js_form_more').fadeIn();
	$('.js_overlay').fadeIn();
})

$('.js_button_click_close').click(function(){
	$('.js_form_more').fadeOut();
	$('.js_overlay').fadeOut();
})

$('.js_button_click_active_consule').click(function(){
	$('.js_form_consule').fadeIn();
	$('.js_overlay').fadeIn();
})

$('.js_button_click_close').click(function(){
	$('.js_form_consule').fadeOut();
	$('.js_overlay').fadeOut();
})
